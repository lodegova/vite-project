module.exports = {
    trailingComma: false,
  };